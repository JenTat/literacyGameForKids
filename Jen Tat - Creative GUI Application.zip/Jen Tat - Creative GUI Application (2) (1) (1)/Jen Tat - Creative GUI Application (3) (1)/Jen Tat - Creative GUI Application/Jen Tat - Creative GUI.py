'''
Created December 8, 2018
For ICS3U

@author: Jen Tat
'''
import csv
from tkinter import *
from AnimatedGif import *
import random
import time
from PIL import Image, ImageTk, ImageSequence

class ToolTip(object):

    def __init__(self, widget):
        self.widget = widget
        self.tipwindow = None
        self.id = None
        self.x = self.y = 0

    def showtip(self, text):
        bg = ""
        theme = themeVar.get()
        if theme == 2:
            bg = "PaleTurquoise1"
        elif theme == 1:
            bg = "peach puff"
        "Display text in tooltip window"
        self.text = text
        if self.tipwindow or not self.text:
            return
        x, y, cx, cy = self.widget.bbox("insert")
        x = x + self.widget.winfo_rootx() + 57
        y = y + cy + self.widget.winfo_rooty() +27
        self.tipwindow = tw = Toplevel(self.widget)
        tw.wm_overrideredirect(1)
        tw.wm_geometry("+%d+%d" % (x, y))
        label = Label(tw, text=self.text, justify=LEFT,
                      background=bg, relief=SOLID, borderwidth=1,
                      font=("Georgia", "8", "normal"))
        label.pack(ipadx=1)

    def hidetip(self):
        tw = self.tipwindow
        self.tipwindow = None
        if tw:
            tw.destroy()

def CreateToolTip(widget, text):
    toolTip = ToolTip(widget)
    def enter(event):
        toolTip.showtip(text)
    def leave(event):
        toolTip.hidetip()
    widget.bind('<Enter>', enter)
    widget.bind('<Leave>', leave)

def getBooks(filename):
    global pictureBookList, chapterBookList, comicBookList, picturePassageList, chapterPassageList, comicPassageList, pictureAuthorList, chapterAuthorList, comicAuthorList, pictureTitleList, chapterTitleList, comicTitleList, allAuthorList, masterBookList
    pictureBookList = []
    chapterBookList = []
    comicBookList = []
    picturePassageList = []
    chapterPassageList = []
    comicPassageList = []
    pictureAuthorList = []
    chapterAuthorList =[]
    comicAuthorList = []
    pictureTitleList = []
    chapterTitleList =[]
    comicTitleList = []
    allAuthorList = []
    masterBookList = []

    fileIn = open(filename, encoding='utf-8')
    fileIn.readline()
    reader = csv.reader(fileIn)
    x = 0
    for line in reader:

        allAuthorList.append(line[2].strip())
        masterBookList.append(line[0 : 3])
        if "Picture" in line[0 : 4]:
            pictureBookList.append(line[0 : 3])
            picturePassageList.append(line[0].strip())
            pictureTitleList.append(line[1].strip())
            pictureAuthorList.append(line[2].strip())

        elif "Chapter" in line[0 : 4]:
            chapterBookList.append(line[0 : 3])
            chapterPassageList.append(line[0].strip())
            chapterTitleList.append(line[1].strip())
            chapterAuthorList.append(line[2].strip())

        elif "Comic" in line[0 : 4]:
            comicBookList.append(line[0 : 3])
            comicPassageList.append(line[0].strip())
            comicTitleList.append(line[1].strip())
            comicAuthorList.append(line[2].strip())

    fileIn.close()

    return pictureBookList, chapterBookList, comicBookList, picturePassageList, chapterPassageList, comicPassageList, pictureAuthorList, chapterAuthorList, comicAuthorList, pictureTitleList, chapterTitleList, comicTitleList, allAuthorList, masterBookList

def main():

    pictureBookList, chapterBookList, comicBookList, picturePassageList, chapterPassageList, comicPassageList, pictureAuthorList, chapterAuthorList, comicAuthorList, pictureTitleList, chapterTitleList, comicTitleList, allAuthorList, masterBookList = getBooks("childrenBooks.csv")

def changeTheme(self):

    myWidgets = [root, mainframe, secframe, titleLabel, lbl_with_my_gif, levelLabel, bookTypeLabel, bookTypesOption, themeScale, incorrectLabel, correctLabel, incorrectCounterLabel, correctCounterLabel]
    labels = [titleLabel, levelLabel, bookTypeLabel, passageLabel, bookTypesOption, themeScale, correctLabel, incorrectLabel, correctCounterLabel, incorrectCounterLabel]
    otherWids = [levelSpinbox, passageFrame, passageLabel, bookTitleFrame, authorFrame, mauthorFrame]
    entries = [authorNameEntry, hbookTitleEntry, mbookTitleEntry]
    radios = [title1Radio, title2Radio, title3Radio, title4Radio, author1Radio, author2Radio, author3Radio, author4Radio, mauthor1Radio, mauthor2Radio, mauthor3Radio, mauthor4Radio]
    buttons = [submitAnswerButton, nextQButton]
    theme = themeVar.get()
##    if dayNight == 1:
##        dayNightScale.config(activebackground="#24467d", bg="#24467d", fg="#24467d", highlightbackground="#24467d", highlightcolor="#24467d", troughcolor="#24467d")
##        root.config(bg="#24467d")
##          root.config(bg="#fcf2ac")
    if theme == 2:
##        dayNightScale.config(activebackground="#fcf2ac", bg="#fcf2ac", fg="#fcf2ac", highlightbackground="#fcf2ac", highlightcolor="#fcf2ac", troughcolor="#fcf2ac")
##        bookTypesOption['menu'].config(activebackground="medium aquamarine")
##        for wid in myWidgets:
##            wid.configure(bg="mint cream")
##            ratingButton.config(bg="lavender", activebackground="#dcf2f5")
##            bookTypesOption.config(activebackground="lavender")
        bookTypesOption['menu'].config(bg="black", fg="white", activebackground="steel blue")
        ratingButton.config(bg="dim gray", fg="white", activebackground="lavender")
        for wid in myWidgets:
            wid.configure(bg="black")
            bookTypesOption.config(activebackground="lavender")

        for lab in labels:
            lab.config(fg="white")

        for ow in otherWids:
            ow.config(bg="black", fg="white")

        for b in buttons:
            b.config(bg="dim gray", fg="white", activebackground="light steel blue")

        for r in radios:
            r.config(bg="black", fg="white", selectcolor="black")

        for e in entries:
            e.config(bg="black", fg="white", insertbackground="white")

    elif theme == 1:
        bookTypesOption['menu'].config(bg="white", fg="black", activebackground="salmon")
        ratingButton.config(bg="seashell", fg="black", activebackground="bisque")
        for wid in myWidgets:
            wid.configure(bg="old lace")
            bookTypesOption.config(activebackground="lemon chiffon")

        for lab in labels:
            lab.config(fg="black")

        for ow in otherWids:
            ow.config(bg="white", fg="black")

        for b in buttons:
            b.config(bg="snow", fg="black", activebackground="honeydew")

        for r in radios:
            r.config(bg="white", fg="black", selectcolor="white")

        for e in entries:
            e.config(bg="white", fg="black", insertbackground="black")

def doneRating():

    serviceLevelLabel.grid_remove()
    serviceScale.grid_remove()
    doneButton.grid_remove()
    cv.delete(ALL)


def getRating():
##    title1Radio.config(text="hello", value="yes")
    cv.delete(ALL)
    badResultLabel.grid_remove()
    retryButton.grid_remove()
    serviceLevelLabel.grid(row=7, column=6, sticky=E)
    serviceScale.grid(row=9, column=5, columnspan=2, ipadx=50)
    doneButton.grid(row=12, column=6)

def changeServiceLevel(self):

     serviceRating = serviceScaleVar.get()
     if serviceRating == 1:
          serviceLevelVar.set("Needs Improvement")
     elif serviceRating == 2:
          serviceLevelVar.set("Below Average")
     elif serviceRating == 3:
          serviceLevelVar.set("Normal")
     elif serviceRating == 4:
          serviceLevelVar.set("Good")
     elif serviceRating == 5:
          serviceLevelVar.set("Excellent")

def displayPassage(self):

    cv.delete(ALL)
    eradioTbuttons = [title1Radio, title2Radio, title3Radio, title4Radio]
    eradioAbuttons = [author1Radio, author2Radio, author3Radio, author4Radio]
    mradiobuttons = [mauthor1Radio, mauthor2Radio, mauthor3Radio, mauthor4Radio]
    level = levelVar.get()
    t = bookTypesOptionVar.get()

    if t == "Picture Book":

        passage = random.choice(picturePassageList)
        pNumber = picturePassageList.index(passage)
        author = pictureAuthorList[pNumber]
        title = pictureTitleList[pNumber]
        passageVar.set(passage)

        aPicList = []
        mPicList = []
        tPicList = []
        for picAu in pictureAuthorList:
            aPicList.append(picAu)

        for picTi in pictureTitleList:
            tPicList.append(picTi)

        for auth in pictureAuthorList:
            mPicList.append(auth)

        eradioAnum = eradioAbuttons[random.randint(0, 3)]
        eradioAnum.config(text=author, value=author)
        eradioAbuttons.remove(eradioAnum)
        aPicList.remove(author)
        for a in range(0, 3):
            aPic = random.choice(aPicList)
            aPicList.remove(aPic)
            eradioAbuttons[a].config(text=aPic, value=aPic)

        eradioTnum = eradioTbuttons[random.randint(0, 3)]
        eradioTnum.config(text=title, value=title)
        eradioTbuttons.remove(eradioTnum)
        tPicList.remove(title)
        for b in range(0, 3):
            tPic = random.choice(tPicList)
            tPicList.remove(tPic)
            eradioTbuttons[b].config(text=tPic, value=tPic)

        mradionum = mradiobuttons[random.randint(0, 3)]
        mradionum.config(text=author, value=author)
        mradiobuttons.remove(mradionum)
        mPicList.remove(author)
        for c in range(0, 3):
            mPic = random.choice(mPicList)
            mPicList.remove(mPic)
            mradiobuttons[c].config(text=mPic, value=mPic)

    elif t == "Chapter Book":
        
        passage = random.choice(chapterPassageList)
        cNumber = chapterPassageList.index(passage)
        authorName = chapterAuthorList[cNumber]
        hapTitle = chapterTitleList[cNumber]
        passageVar.set(passage)

        aChapList = []
        mChapList = []
        tChapList = []
        for chapAu in chapterAuthorList:
            aChapList.append(chapAu)

        for chapTho in chapterAuthorList:
            mChapList.append(chapTho)

        for chapTi in chapterTitleList:
            tChapList.append(chapTi)
            
        eradioAnum = eradioAbuttons[random.randint(0, 3)]
        eradioAnum.config(text=authorName, value=authorName)
        eradioAbuttons.remove(eradioAnum)
        aChapList.remove(authorName)
        for x in range(0, 3):
            aChap = random.choice(aChapList)
            aChapList.remove(aChap)
            eradioAbuttons[x].config(text=aChap, value=aChap)

        eradioTnum = eradioTbuttons[random.randint(0, 3)]
        eradioTnum.config(text=hapTitle, value=hapTitle)
        eradioTbuttons.remove(eradioTnum)
        tChapList.remove(hapTitle)
        for y in range(0, 3):
            tChap = random.choice(tChapList)
            tChapList.remove(tChap)
            eradioTbuttons[y].config(text=tChap, value=tChap)

        mradionum = mradiobuttons[random.randint(0, 3)]
        mradionum.config(text=authorName, value=authorName)
        mradiobuttons.remove(mradionum)
        mChapList.remove(authorName)
        for z in range(0, 3):
            mChap = random.choice(mChapList)
            mChapList.remove(mChap)
            mradiobuttons[z].config(text=mChap, value=mChap)
    
    elif t == "Comic Book":
        
        passage = random.choice(comicPassageList)
        oNumber = comicPassageList.index(passage)
        comAuthor = comicAuthorList[oNumber]
        oTitle = comicTitleList[oNumber]
        passageVar.set(passage)

        aComList = []
        mComList = []
        tComList = []
        for comA in comicAuthorList:
            aComList.append(comA)

        for comU in comicAuthorList:
            mComList.append(comU)

        for comT in comicTitleList:
            tComList.append(comT)

        eradioAnum = eradioAbuttons[random.randint(0, 3)]
        eradioAnum.config(text=comAuthor, value=comAuthor)
        eradioAbuttons.remove(eradioAnum)
        aComList.remove(comAuthor)
        for j in range(0, 3):
            aCom = random.choice(aComList)
            aComList.remove(aCom)
            eradioAbuttons[j].config(text=aCom, value=aCom)

        eradioTnum = eradioTbuttons[random.randint(0, 3)]
        eradioTnum.config(text=oTitle, value=oTitle)
        eradioTbuttons.remove(eradioTnum)
        tComList.remove(oTitle)
        for k in range(0, 3):
            tCom = random.choice(tComList)
            tComList.remove(tCom)
            eradioTbuttons[k].config(text=tCom, value=tCom)

        mradionum = mradiobuttons[random.randint(0, 3)]
        mradionum.config(text=comAuthor, value=comAuthor)
        mradiobuttons.remove(mradionum)
        mComList.remove(comAuthor)
        for l in range(0, 3):
            mCom = random.choice(mComList)
            mComList.remove(mCom)
            mradiobuttons[l].config(text=mCom, value=mCom)

##def displayPassage(self):
##
##    eradioTbuttons = [title1Radio, title2Radio, title3Radio, title4Radio]
##    eradioAbuttons = [author1Radio, author2Radio, author3Radio, author4Radio]
##    mradiobuttons = [mauthor1Radio, mauthor2Radio, mauthor3Radio, mauthor4Radio]
##    level = levelVar.get()
##    t = bookTypesOptionVar.get()
####    for eradT in eradioTbuttons:
####        eradT.grid_remove()
####
####    for eradA in eradioAbuttons:
####        eradA.grid_remove()
####
####    for mrad in mradiobuttons:
####        mrad.grid_remove()
##
##    if t == "Picture Book":
##        passageVar.set(random.choice(picturePassageList))
##
##    ##        if level == "Easy":
##    ##            for eradT in eradioTbuttons:
##    ##                eradT.grid_remove()
##    ##
##    ##            for eradA in eradioAbuttons:
##    ##                eradA.grid_remove()
##    ##
##    ##            for mrad in mradiobuttons:
##    ##                mrad.grid_remove()
##
##        aPicList = pictureAuthorList.copy()
##        for a in range(0, 4):
##            aPic = random.choice(aPicList)
##            eradioAbuttons[a].config(text=aPic, value=aPic)
##            aPicList.remove(aPic)
##
##        tPicList = pictureTitleList.copy()
##        for b in range(0, 4):
##            tPic = random.choice(tPicList)
##            eradioTbuttons[b].config(text=tPic, value=tPic)
##            tPicList.remove(tPic)
##
##    ##        elif level == "Medium":
##    ##            for eradT in eradioTbuttons:
##    ##                eradT.grid_remove()
##    ##
##    ##            for eradA in eradioAbuttons:
##    ##                eradA.grid_remove()
##
##        mPicList = pictureAuthorList.copy()
##        for c in range(0, 4):
##            mPic = random.choice(mPicList)
##            mradiobuttons[c].config(text=mPic, value=mPic)
##            mPicList.remove(mPic)
##
##    elif t == "Chapter Book":
##        passageVar.set(random.choice(chapterPassageList))
####        a = random.choice(chapterAuthorList)
##
####        if level == "Easy":
####            for mrad in mradiobuttons:
####                mrad.grid_remove()
##
##        aChapList = chapterAuthorList.copy()
##        for x in range(0, 4):
##            aChap = random.choice(aChapList)
##            eradioAbuttons[x].config(text=aChap, value=aChap)
##            aChapList.remove(aChap)
##
##        tChapList = chapterTitleList.copy()
##        for y in range(0, 4):
##            tChap = random.choice(tChapList)
##            eradioTbuttons[y].config(text=tChap, value=tChap)
##            tChapList.remove(tChap)
##
####        elif level == "Medium":
####            for eradT in eradioTbuttons:
####                eradT.grid_remove()
####
####            for eradA in eradioAbuttons:
####                eradA.grid_remove()
##
##        mChapList = chapterAuthorList.copy()
##        for z in range(0, 4):
##            mChap = random.choice(mChapList)
##            mradiobuttons[z].config(text=mChap, value=mChap)
##            mChapList.remove(mChap)
##
####        aChapList = chapterAuthorList.copy()
####        for x in range(0, 4):
####            aChap = random.choice(aChapList)
####            eradioAbuttons[x].config(text=aChap, value=aChap)
####            aChapList.remove(aChap)
####
####        tChapList = chapterTitleList.copy()
####        for y in range(0, 4):
####            tChap = random.choice(tChapList)
####            eradioTbuttons[y].config(text=tChap, value=tChap)
####            tChapList.remove(tChap)
####
####        mChapList = chapterAuthorList.copy()
####        for z in range(0, 4):
####            mChap = random.choice(mChapList)
####            mradiobuttons[z].config(text=mChap, value=mChap)
####            mChapList.remove(mChap)
##
##    elif t == "Comic Book":
##        passageVar.set(random.choice(comicPassageList))
##
####        if level == "Easy":
####            for mrad in mradiobuttons:
####                mrad.grid_remove()
##
##        aComList = comicAuthorList.copy()
##        for j in range(0, 4):
##            aCom = random.choice(aComList)
##            eradioAbuttons[j].config(text=aCom, value=aCom)
##            aComList.remove(aCom)
##
##        tComList = comicTitleList.copy()
##        for k in range(0, 4):
##            tCom = random.choice(tComList)
##            eradioTbuttons[k].config(text=tCom, value=tCom)
##            tComList.remove(tCom)
##
####        elif level == "Medium":
####            for eradT in eradioTbuttons:
####                eradT.grid_remove()
####
####            for eradA in eradioAbuttons:
####                eradA.grid_remove()
##
##        mComList = comicAuthorList.copy()
##        for l in range(0, 4):
##            mCom = random.choice(mComList)
##            mradiobuttons[l].config(text=mCom, value=mCom)
##            mComList.remove(mCom)
##
####        aComList = comicAuthorList.copy()
####        for j in range(0, 4):
####            aCom = random.choice(aComList)
####            eradioAbuttons[j].config(text=aCom, value=aCom)
####            aComList.remove(aCom)
####
####        tComList = comicTitleList.copy()
####        for k in range(0, 4):
####            tCom = random.choice(tComList)
####            eradioTbuttons[k].config(text=tCom, value=tCom)
####            tComList.remove(tCom)
####
####        mComList = comicAuthorList.copy()
####        for l in range(0, 4):
####            mCom = random.choice(mComList)
####            mradiobuttons[l].config(text=mCom, value=mCom)
####            mComList.remove(mCom)

##def displayPassage(self):
##
####    t = bookTypesOptionVar.get()
####    if t == "Picture Book":
####        doneButton.grid(row=4, column=3)
##    pass

def levelChange():

    cv.delete(ALL)
    eradiobuttons = [title1Radio, title2Radio, title3Radio, title4Radio, author1Radio, author2Radio, author3Radio, author4Radio]
    mradiobuttons = [mauthor1Radio, mauthor2Radio, mauthor3Radio, mauthor4Radio]
    level = levelVar.get()
    if level == "Easy":

        mauthorFrame.grid_remove()
        for mrad in eradiobuttons:
            mrad.grid_remove()
        authorFrame.grid(ipadx=35)
        hbookTitleEntry.grid_remove()
        mbookTitleEntry.grid_remove()
        authorNameEntry.grid_remove()

        title1Radio.grid(row=1, sticky=W)
        title2Radio.grid(row=2, sticky=W)
        title3Radio.grid(row=3, sticky=W)
        title4Radio.grid(row=4, sticky=W)

        author1Radio.grid(row=1, sticky=W)
        author2Radio.grid(row=2, sticky=W)
        author3Radio.grid(row=3, sticky=W)
        author4Radio.grid(row=4, sticky=W)

    elif level == "Medium":

        authorFrame.grid_remove()
        for erad in eradiobuttons:
            erad.grid_remove()

        authorNameEntry.grid_remove()
        hbookTitleEntry.grid_remove()

        bookTitleFrame.grid(sticky=NW)
        mauthorFrame.grid(row=7, column=2, sticky=W, ipadx=35)
        mbookTitleEntry.grid(row=1, ipadx=10, ipady=10, padx=2, pady=2)

        num = 1
        for mrad in mradiobuttons:
            mrad.grid(row=num, sticky=W)
            num += 1

    elif level == "Hard":

        for erad in eradiobuttons:
            erad.grid_remove()

        for mrad in mradiobuttons:
            mrad.grid_remove()

        mbookTitleEntry.grid_remove()
        mauthorFrame.grid_remove()
        authorFrame.grid(ipadx=15)
        hbookTitleEntry.grid(row=1, ipadx=12, ipady=10, sticky=W, padx=2, pady=2)
        authorNameEntry.grid(row=1, ipadx=12, ipady=10, sticky=W, padx=2, pady=2)

def tryAgain():

    cv.delete(ALL)
    badResultLabel.grid_remove()
    retryButton.grid_remove()

def rightAnswer(bookIndex):

    cv.delete(ALL)
    doneRating()
    badResultLabel.grid_remove()
    retryButton.grid_remove()
    book = masterBookList[bookIndex]
    bookTit = book[1]
    correctCounter = int(correctCounterStringVar.get())
    correctCounter += 1
    correctCounterStringVar.set(correctCounter)
    if bookTit == "Green Eggs and Ham":
        cv.create_image(150, 250, image=greenEggsHamPhoto)
        cv.create_image(375, 250, image=goodStickerPhoto)
    elif bookTit == "No, David!":
        cv.create_image(150, 250, image=noDavidPhoto)
        cv.create_image(375, 250, image=goodStickerPhoto)
    elif bookTit == "The Paper Bag Princess":
        cv.create_image(175, 250, image=bagPrincessPhoto)
        cv.create_image(415, 250, image=goodStickerPhoto)
    elif bookTit == "The Giving Tree":
        cv.create_image(150, 250, image=givingTreePhoto)
        cv.create_image(375, 250, image=goodStickerPhoto)
    elif bookTit == "The Rainbow Fish":
        cv.create_image(150, 250, image=rainbowFishPhoto)
        cv.create_image(375, 250, image=goodStickerPhoto)
    elif bookTit == "Corduroy":
        cv.create_image(175, 250, image=corduroyPhoto)
        cv.create_image(415, 250, image=goodStickerPhoto)
    elif bookTit == "Diary of a Wimpy Kid":
        cv.create_image(150, 250, image=wimpyKidPhoto)
        cv.create_image(375, 250, image=goodStickerPhoto)
    elif bookTit == "Charlotte's Web":
        cv.create_image(150, 250, image=charlWebPhoto)
        cv.create_image(375, 250, image=goodStickerPhoto)
    elif bookTit == "James and the Giant Peach":
        cv.create_image(150, 250, image=jamesPeachPhoto)
        cv.create_image(375, 250, image=goodStickerPhoto)
    elif bookTit == "The Merry Adventures of Robin Hood":
        cv.create_image(150, 250, image=robinHoodPhoto)
        cv.create_image(375, 250, image=goodStickerPhoto)
    elif bookTit == "Wonder":
        cv.create_image(150, 250, image=wonderPhoto)
        cv.create_image(375, 250, image=goodStickerPhoto)
    elif bookTit == "Pippi Longstocking":
        cv.create_image(150, 250, image=pippiPhoto)
        cv.create_image(375, 250, image=goodStickerPhoto)
    elif bookTit == "Smile":
        cv.create_image(150, 250, image=smilePhoto)
        cv.create_image(375, 250, image=goodStickerPhoto)
    elif bookTit == "Out from Boneville":
        cv.create_image(150, 250, image=bonevillePhoto)
        cv.create_image(375, 250, image=goodStickerPhoto)
    elif bookTit == "Amulet: The Stonekeeper":
        cv.create_image(150, 250, image=stoneKeeperPhoto)
        cv.create_image(375, 250, image=goodStickerPhoto)
    elif bookTit == "Big Nate: In a Class by Himself":
        cv.create_image(150, 250, image=bigNatePhoto)
        cv.create_image(375, 250, image=goodStickerPhoto)
    elif bookTit == "Archie Comics":
        cv.create_image(150, 250, image=archiePhoto)
        cv.create_image(375, 250, image=goodStickerPhoto)
    elif bookTit == "El Deafo":
        cv.create_image(150, 250, image=elDeafoPhoto)
        cv.create_image(375, 250, image=goodStickerPhoto)

def wrongAnswer():

    cv.delete(ALL)
    doneRating()
    badResultLabel.grid_remove()
    retryButton.grid_remove()
    incorrectCounter = int(incorrectCounterStringVar.get())
    incorrectCounter += 1
    incorrectCounterStringVar.set(incorrectCounter)
    badResultLabel.grid(row=5, column=7)
    cv.create_image(250, 250, image=frownyFacePhoto)
    retryButton.grid(row=13, column=6, columnspan=4, rowspan=2)

def submitAnswerResults():

    cv.delete(ALL)
    level = levelVar.get()
    passage = passageVar.get()
    titleRadioAnswer = titleVar.get()
    nameRadioAnswer = authorVar.get()
    mnameRadioAnswer = mauthorVar.get()
    mtitleEntryAnswer = mbookTitleVar.get()
    htitleEntryAnswer = hbookTitleVar.get()
    nameEntryAnswer = authorNameVar.get()

    for m in masterBookList:

        if passage in m:
            index = masterBookList.index(m)

    if level == "Easy":
        lbl_with_my_gif = AnimatedGif(cv, 'good.gif', 0.05)
        if titleRadioAnswer in masterBookList[index] and nameRadioAnswer in masterBookList[index]:
            rightAnswer(index)

        else:
            wrongAnswer()

    if level == "Medium":

        book = masterBookList[index]
        if mtitleEntryAnswer.lower() == book[1].lower() and mnameRadioAnswer in masterBookList[index]:
            rightAnswer(index)
        else:
            wrongAnswer()

    if level == "Hard":

        book = masterBookList[index]
        if htitleEntryAnswer.lower() == book[1].lower() and nameEntryAnswer.lower() == book[2].lower():
            rightAnswer(index)
        else:
            wrongAnswer()

def newQuestion():

    cv.delete(ALL)
    mtitleEntryAnswer = mbookTitleVar.set("")
    htitleEntryAnswer = hbookTitleVar.set("")
    nameEntryAnswer = authorNameVar.set("")
    badResultLabel.grid_remove()
    retryButton.grid_remove()
    passage = passageVar.get()
    typeOfBook = bookTypesOptionVar.get()
    eradioTbuttons = [title1Radio, title2Radio, title3Radio, title4Radio]
    eradioAbuttons = [author1Radio, author2Radio, author3Radio, author4Radio]
    mradiobuttons = [mauthor1Radio, mauthor2Radio, mauthor3Radio, mauthor4Radio]
    picText = []
    chapText = []
    comText = []

    for p in picturePassageList:
        picText.append(p)

    for h in chapterPassageList:
        chapText.append(h)

    for o in comicPassageList:
        comText.append(o)

    if typeOfBook == "Picture Book":

        picText.remove(passage)
        piText = random.choice(picText)
        passageVar.set(piText)
        authList = []
        thList = []
        picTitList = []
        numIn = picturePassageList.index(piText)
        author = pictureAuthorList[numIn]
        picTit = pictureTitleList[numIn]
        eradioTnum = eradioTbuttons[random.randint(0, 3)]
        eradioTnum.config(text=picTit, value=picTit)
        eradioTbuttons.remove(eradioTnum)
        eradioAnum = eradioAbuttons[random.randint(0, 3)]
        eradioAnum.config(text=author, value=author)
        eradioAbuttons.remove(eradioAnum)
        mradioNum = mradiobuttons[random.randint(0, 3)]
        mradioNum.config(text=author, value=author)
        mradiobuttons.remove(mradioNum)

        for pt in pictureTitleList:
            picTitList.append(pt)

        picTitList.remove(picTit)
        for pi in range(0, 3):
            ptl = random.choice(picTitList)
            picTitList.remove(ptl)
            eradioTbuttons[pi].config(text=ptl, value=ptl) 
        
        for au in pictureAuthorList:
            authList.append(au)

        authList.remove(author)
        for a in range(0, 3):
            auth = random.choice(authList)
            authList.remove(auth)
            eradioAbuttons[a].config(text=auth, value=auth)

        for th in pictureAuthorList:
            thList.append(th)

        thList.remove(author)
        for h in range(0, 3):
            tho = random.choice(thList)
            thList.remove(tho)
            mradiobuttons[h].config(text=tho, value=tho)
            
    elif typeOfBook == "Chapter Book":

        chapText.remove(passage)
        chaText = random.choice(chapText)
        passageVar.set(chaText)
        cauthList = []
        cthList = []
        chapTitList = []
        cnumIn = chapterPassageList.index(chaText)
        cauthor = chapterAuthorList[cnumIn]
        chapTit = chapterTitleList[cnumIn]
        eradioTnum = eradioTbuttons[random.randint(0, 3)]
        eradioTnum.config(text=chapTit, value=chapTit)
        eradioTbuttons.remove(eradioTnum)
        eradioAnum = eradioAbuttons[random.randint(0, 3)]
        eradioAnum.config(text=cauthor, value=cauthor)
        eradioAbuttons.remove(eradioAnum)
        mradioNum = mradiobuttons[random.randint(0, 3)]
        mradioNum.config(text=cauthor, value=cauthor)
        mradiobuttons.remove(mradioNum)

        for ct in chapterTitleList:
            chapTitList.append(ct)

        chapTitList.remove(chapTit)
        for ch in range(0, 3):
            ctl = random.choice(chapTitList)
            chapTitList.remove(ctl)
            eradioTbuttons[ch].config(text=ctl, value=ctl) 
        
        for cau in chapterAuthorList:
            cauthList.append(cau)

        cauthList.remove(cauthor)
        for ca in range(0, 3):
            cauth = random.choice(cauthList)
            cauthList.remove(cauth)
            eradioAbuttons[ca].config(text=cauth, value=cauth)

        for cth in chapterAuthorList:
            cthList.append(cth)

        cthList.remove(cauthor)
        for ha in range(0, 3):
            ctho = random.choice(cthList)
            cthList.remove(ctho)
            mradiobuttons[ha].config(text=ctho, value=ctho)
        
    elif typeOfBook == "Comic Book":

        comText.remove(passage)
        coText = random.choice(comText)
        passageVar.set(coText)
        oauthList = []
        othList = []
        comTitList = []
        onumIn = comicPassageList.index(coText)
        oauthor = comicAuthorList[onumIn]
        comTit = comicTitleList[onumIn]
        eradioTnum = eradioTbuttons[random.randint(0, 3)]
        eradioTnum.config(text=comTit, value=comTit)
        eradioTbuttons.remove(eradioTnum)
        eradioAnum = eradioAbuttons[random.randint(0, 3)]
        eradioAnum.config(text=oauthor, value=oauthor)
        eradioAbuttons.remove(eradioAnum)
        mradioNum = mradiobuttons[random.randint(0, 3)]
        mradioNum.config(text=oauthor, value=oauthor)
        mradiobuttons.remove(mradioNum)

        for ot in comicTitleList:
            comTitList.append(ot)

        comTitList.remove(comTit)
        for om in range(0, 3):
            otl = random.choice(comTitList)
            comTitList.remove(otl)
            eradioTbuttons[om].config(text=otl, value=otl) 
        
        for oau in comicAuthorList:
            oauthList.append(oau)

        oauthList.remove(oauthor)
        for ic in range(0, 3):
            oauth = random.choice(oauthList)
            oauthList.remove(oauth)
            eradioAbuttons[ic].config(text=oauth, value=oauth)

        for oth in comicAuthorList:
            othList.append(oth)

        othList.remove(oauthor)
        for co in range(0, 3):
            mi = random.choice(othList)
            othList.remove(mi)
            mradiobuttons[co].config(text=mi, value=mi)
##def addImage(event):
##    global weather, weatherPictures
##
##    #get the mouse click location (x, y)
##    x = event.x
##    y = event.y
##
##    #get the Option Menu selection
##    weatherOption = weatherOptionVar.get()
##
##    #find the index of the selection in the weather list
##    weatherIndex = weather.index(weatherOption)
##
##    #use the index to find the correct PhotoImage in the weatherPictures list
##    photoToUse = weatherPictures[weatherIndex]
##
##    #The function create_image below will add an image to the canvas
##    cv.create_image(x, y, image=photoToUse)


def clearScreen():
    cv.delete(ALL)
    optionButton.grid_remove()

def thumbnails(frames):
    for frame in frames:
        thumbnail = frame.copy()
        thumbnail.thumbnail(size, Image.ANTIALIAS)
        yield thumbnail

#MAIN
#Holding frames
#########
root = Tk()
root.title("Bet A Book")
mainframe = Frame(root)
secframe = Frame(root)

#Widgets
#########
main()

cv = Canvas(secframe, width=500, height=500)
##, bg="#a8b1bf")
##cv.bind("<Button-1>", submitAnswerResults)

global bgcolour
bgcolour = "old lace"
root.config(bg="old lace")
mainframe.config(bg="old lace")
secframe.config(bg="old lace")

# Output (max) size
size = 300, 225

# Open source
im = Image.open("book.gif")
im2 = Image.open("book1.gif")
im3 = Image.open("brownBook.gif")

# Get sequence iterator
frames = ImageSequence.Iterator(im)
frames2 = ImageSequence.Iterator(im2)
frames3 = ImageSequence.Iterator(im3)

# Wrap on-the-fly thumbnail generator
frames = thumbnails(frames)
frames2 = thumbnails(frames2)
frames3 = thumbnails(frames3)

# Save output
om = next(frames) # Handle first frame separately
om.info = im.info # Copy sequence info
om.save("out.gif", save_all=True, append_images=list(frames))

om2 = next(frames2)
om2.info = im2.info
om2.save("out2.gif", save_all=True, append_images=list(frames2))

om3 = next(frames3)
om3.info = im3.info
om3.save("out3.gif", save_all=True, append_images=list(frames3))

gifList = ["out.gif", "book2.gif", "out2.gif", "out3.gif"]
lbl_with_my_gif = AnimatedGif(mainframe, random.choice(gifList), 0.16)  # (tkinter.parent, filename, delay between frames)
##lbl_with_my_gif.grid(row=1, column=2)  # Packing the label with the animated gif (grid works just as well)
lbl_with_my_gif.config(bg=bgcolour)
lbl_with_my_gif.start()  # Shows gif at first frame and we are ready to go

titleLabel = Label(mainframe, bg=bgcolour, text="Bet A Book", font=("Courier", 30))
CreateToolTip(titleLabel, text = 'Hey you!\nThis is a strict game!\nYou will only get the question right if you have:\nall the words and punctuation in the book title,\nproperly spelt words,\nand both first and last names (some authors prefer using their initials).\nThis game may allow you to get away with disregarding capitals,\nbut it would be good practice to format names and titles correctly.\nGOOD LUCK!')

levelLabel = Label(mainframe, bg=bgcolour, text="Level of Difficulty", font=("Bookman Old Style", 16))
global levels
levels = ["Easy", "Medium", "Hard"]
levelVar = StringVar()
levelVar.set("Easy")
levelSpinbox = Spinbox(mainframe, width=13, textvariable=levelVar, values=levels, font=('Bookman Old Style', 14), command=levelChange)

bookTypeLabel = Label(mainframe, bg=bgcolour, text="Choose a type of book", font=("Bookman Old Style", 16))
global bookTypes
bookTypes = ["Picture Book", "Chapter Book", "Comic Book"]
bookTypesOptionVar = StringVar()
bookTypesOptionVar.set("Picture Book")
bookTypesOption = OptionMenu(mainframe, bookTypesOptionVar, *bookTypes, command=displayPassage)
bookTypesOption.config(bg=bgcolour, activebackground="lemon chiffon", width=11, font=("Bookman Old Style", 14))
bookTypesOption['menu'].config(font=('Calibri',(14)),bg='white', activebackground="salmon")

passageFrame = LabelFrame(mainframe, text="Book Passage:", font=("Bookman Old Style", 12), bg="white")
passageVar = StringVar()
##passageVar.set("Book Passage...")
text = random.choice(picturePassageList)
passageVar.set(text)
passageLabel = Label(passageFrame, textvariable=passageVar, font=("Times New Roman", 18), anchor=NW, wraplength=500, bg='white')

themeVar = IntVar()
themeVar.set(1)
themeScale = Scale(mainframe, variable=themeVar, label="Theme", bg=bgcolour, troughcolor="white", width=50, length=100, from_=1, to=2, showvalue=False, orient=HORIZONTAL, command=changeTheme, font=("Bookman Old Style", 14))

ratingButton = Button(mainframe, text="Give us a rating!", command=getRating, width=15, height=2, font=("Bookman Old Style", 12), bg="seashell", activebackground="bisque")

titlesList = []
for p in pictureTitleList:
    titlesList.append(p)
bookTitleFrame = LabelFrame(mainframe, text="What is the book title?", font=("Bookman Old Style", 12), bg="white")
titleVar = StringVar()
title1RadTV = pictureTitleList[picturePassageList.index(text)]
titlesList.remove(title1RadTV)
title2RadTV = random.choice(titlesList)
titlesList.remove(title2RadTV)
title3RadTV = random.choice(titlesList)
titlesList.remove(title3RadTV)
title4RadTV = random.choice(titlesList)
global title1RadTv, title2RadTv, title3RadTv, title4RadTv

title1Radio = Radiobutton(bookTitleFrame, text=title1RadTV, variable=titleVar, value=title1RadTV, bg="white", font=("Bookman Old Style", 11))
title2Radio = Radiobutton(bookTitleFrame, text=title2RadTV, variable=titleVar, value=title2RadTV, bg="white", font=("Bookman Old Style", 11))
title3Radio = Radiobutton(bookTitleFrame, text=title3RadTV, variable=titleVar, value=title3RadTV, bg="white", font=("Bookman Old Style", 11))
title4Radio = Radiobutton(bookTitleFrame, text=title4RadTV, variable=titleVar, value=title4RadTV, bg="white", font=("Bookman Old Style", 11))

hbookTitleVar = StringVar()
hbookTitleEntry = Entry(bookTitleFrame, textvariable=hbookTitleVar)
hbookTitleEntry.config(relief=FLAT, font=("Bookman Old Style", 11))

mbookTitleVar = StringVar()
mbookTitleEntry = Entry(bookTitleFrame, textvariable=mbookTitleVar)
mbookTitleEntry.config(relief=FLAT, font=("Bookman Old Style", 11))

authorsList = []
for p in pictureAuthorList:
    authorsList.append(p)
authorFrame = LabelFrame(mainframe, text="What is the author?", font=("Bookman Old Style", 12), bg="white")
authorVar = StringVar()
author1RadTV = pictureAuthorList[picturePassageList.index(text)]
authorsList.remove(author1RadTV)
author2RadTV = random.choice(authorsList)
authorsList.remove(author2RadTV)
author3RadTV = random.choice(authorsList)
authorsList.remove(author3RadTV)
author4RadTV = random.choice(authorsList)
global author1RadTv, author2RadTv, author3RadTv, author4RadTv

author1Radio = Radiobutton(authorFrame, text=author1RadTV, variable=authorVar, value=author1RadTV, bg="white", font=("Bookman Old Style", 11))
author2Radio = Radiobutton(authorFrame, text=author2RadTV, variable=authorVar, value=author2RadTV, bg="white", font=("Bookman Old Style", 11))
author3Radio = Radiobutton(authorFrame, text=author3RadTV, variable=authorVar, value=author3RadTV, bg="white", font=("Bookman Old Style", 11))
author4Radio = Radiobutton(authorFrame, text=author4RadTV, variable=authorVar, value=author4RadTV, bg="white", font=("Bookman Old Style", 11))

mediumAuthorsList = []
for u in pictureAuthorList:
    mediumAuthorsList.append(u)
mauthorVar = StringVar()
mauthor1RadTV = pictureAuthorList[picturePassageList.index(text)]
mediumAuthorsList.remove(mauthor1RadTV)
mauthor2RadTV = random.choice(mediumAuthorsList)
mediumAuthorsList.remove(mauthor2RadTV)
mauthor3RadTV = random.choice(mediumAuthorsList)
mediumAuthorsList.remove(mauthor3RadTV)
mauthor4RadTV = random.choice(mediumAuthorsList)
global muthor1RadTv, mauthor2RadTv, mauthor3RadTv, mauthor4RadTv

mauthorFrame = LabelFrame(mainframe, text="What is the author?", font=("Bookman Old Style", 12), bg="white")
mauthor1Radio = Radiobutton(mauthorFrame, text=mauthor1RadTV, variable=mauthorVar, value=mauthor1RadTV, bg="white", font=("Bookman Old Style", 11))
mauthor2Radio = Radiobutton(mauthorFrame, text=mauthor2RadTV, variable=mauthorVar, value=mauthor2RadTV, bg="white", font=("Bookman Old Style", 11))
mauthor3Radio = Radiobutton(mauthorFrame, text=mauthor3RadTV, variable=mauthorVar, value=mauthor3RadTV, bg="white", font=("Bookman Old Style", 11))
mauthor4Radio = Radiobutton(mauthorFrame, text=mauthor4RadTV, variable=mauthorVar, value=mauthor4RadTV, bg="white", font=("Bookman Old Style", 11))

authorNameVar = StringVar()
authorNameEntry = Entry(authorFrame, textvariable=authorNameVar)
authorNameEntry.config(relief=FLAT, font=("Bookman Old Style", 11))

serviceScaleVar = IntVar()
serviceScaleVar.set(3)
serviceScale = Scale(secframe, from_=1, to=5, variable = serviceScaleVar, showvalue=False, label="Service Rating", orient=VERTICAL, length=200, troughcolor="lavender blush", font=("Bookman Old Style", 10))
serviceScale.bind("<B1-Motion>", changeServiceLevel)

serviceLevelVar = StringVar()
serviceLevelVar.set("Normal")
serviceLevelLabel = Label(secframe, font=("Courier", 24), textvariable = serviceLevelVar)

submitAnswerButton = Button(mainframe, text="Give me my results!", command=submitAnswerResults, width=20, height=2, font=("Bookman Old Style", 12), bg="snow", activebackground="honeydew")
nextQButton = Button(mainframe, text="Next Question!", command=newQuestion, width=23, height=2, font=("Bookman Old Style", 12), bg="snow", activebackground="honeydew")

doneButton = Button(secframe, text="Done!", command=doneRating, width=15, height=2, font=("Bookman Old Style", 12), bg="snow", activebackground="honeydew")

badResultVar = StringVar()
badResultVar.set("Incorrect!\nPlease try again!")
badResultLabel = Label(secframe, font=("Courier", 24), textvariable = badResultVar)

retryButton = Button(secframe, text="Try Again", command=tryAgain, width=20, height=2, font=("Bookman Old Style", 12), bg="snow", activebackground="honeydew")
CreateToolTip(retryButton, text = "Hey you!\nDon't get discouraged!\nTo get the question right, you need to have:\nall the words and punctuation in the book title,\nproperly spelt words,\nand both first and last names (some authors prefer using their initials).\nThis game may allow you to get away with disregarding capitals,\nbut it would be good practice to format names and titles correctly.\nGOOD LUCK!")

correctLabelStringVar = StringVar()
correctLabelStringVar.set("Correct:")
correctLabel = Label(mainframe, text="", font=("Courier", 16), textvariable=correctLabelStringVar, bg=bgcolour)

correctCounterStringVar = StringVar()
correctCounterStringVar.set(0)
correctCounterLabel = Label(mainframe, text="", font=("Courier", 16), textvariable=correctCounterStringVar, bg=bgcolour)

incorrectLabelStringVar = StringVar()
incorrectLabelStringVar.set("Incorrect:")
incorrectLabel = Label(mainframe, text="", font=("Courier", 16), textvariable=incorrectLabelStringVar, bg=bgcolour)

incorrectCounterStringVar = StringVar()
incorrectCounterStringVar.set(0)
incorrectCounterLabel = Label(mainframe, text="", font=("Courier", 16), textvariable=incorrectCounterStringVar, bg=bgcolour)

##sunImage = Image.open("sun.png").resize((200, 200))
##sunPhoto = ImageTk.PhotoImage(sunImage)
##cloudImage = Image.open("clouds.png").resize((200, 200))
##cloudPhoto = ImageTk.PhotoImage(cloudImage)
##rainImage = Image.open("rain.png").resize((200, 200))
##rainPhoto = ImageTk.PhotoImage(rainImage)
##cloudyImage = Image.open("cloudy.png").resize((200, 200))
##cloudyPhoto = ImageTk.PhotoImage(cloudyImage)
##
##global weatherPictures
##weatherPictures = [sunPhoto, cloudyPhoto, cloudPhoto, rainPhoto]
##
##global weather
##weather = ["Sun", "Sun/Clouds", "Cloudy", "Rain"]
##weatherOptionVar = StringVar()
##weatherOptionVar.set("Sun")
##weatherOption = OptionMenu(mainframe, weatherOptionVar, *weather)
##weatherOption.config(width=20)
##
##clearButton = Button(mainframe, text="CLEAR", command=clearScreen)
##
##optionButton = Button(secframe, text="Hello")
frownyFaceImage = Image.open("frownyFace.png").resize((200, 200))
frownyFacePhoto = ImageTk.PhotoImage(frownyFaceImage)

goodStickerImage = Image.open("goodSticker.png").resize((200, 200))
goodStickerPhoto = ImageTk.PhotoImage(goodStickerImage)

greenEggsHamImage = Image.open("greenEggsHam.jpg").resize((250, 350))
greenEggsHamPhoto = ImageTk.PhotoImage(greenEggsHamImage)

noDavidImage = Image.open("noDavid.jpg").resize((250, 350))
noDavidPhoto = ImageTk.PhotoImage(noDavidImage)

bagPrincessImage = Image.open("bagPrincess.jpg").resize((300, 300))
bagPrincessPhoto = ImageTk.PhotoImage(bagPrincessImage)

rainbowFishImage = Image.open("rainbowFish.jpg").resize((250, 350))
rainbowFishPhoto = ImageTk.PhotoImage(rainbowFishImage)

givingTreeImage = Image.open("givingTree.jpg").resize((250, 350))
givingTreePhoto = ImageTk.PhotoImage(givingTreeImage)

wimpyKidImage = Image.open("wimpyKid.jpg").resize((250, 350))
wimpyKidPhoto = ImageTk.PhotoImage(wimpyKidImage)

charlWebImage = Image.open("charlWeb.jpg").resize((250, 350))
charlWebPhoto = ImageTk.PhotoImage(charlWebImage)

jamesPeachImage = Image.open("jamesPeach.jpg").resize((250, 350))
jamesPeachPhoto = ImageTk.PhotoImage(jamesPeachImage)

robinHoodImage = Image.open("robinHood.jpg").resize((250, 350))
robinHoodPhoto = ImageTk.PhotoImage(robinHoodImage)

smileImage = Image.open("smile.png").resize((250, 350))
smilePhoto = ImageTk.PhotoImage(smileImage)

bonevilleImage = Image.open("boneville.jpg").resize((250, 350))
bonevillePhoto = ImageTk.PhotoImage(bonevilleImage)

stoneKeeperImage = Image.open("stoneKeeper.jpg").resize((250, 350))
stoneKeeperPhoto = ImageTk.PhotoImage(stoneKeeperImage)

bigNateImage = Image.open("bigNate.jpg").resize((250, 350))
bigNatePhoto = ImageTk.PhotoImage(bigNateImage)

wonderImage = Image.open("wonder.jpg").resize((250, 350))
wonderPhoto = ImageTk.PhotoImage(wonderImage)

archieImage = Image.open("archie.jpg").resize((250, 350))
archiePhoto = ImageTk.PhotoImage(archieImage)

corduroyImage = Image.open("corduroy.jpg").resize((300, 300))
corduroyPhoto = ImageTk.PhotoImage(corduroyImage)

pippiImage = Image.open("pippi.jpg").resize((250, 350))
pippiPhoto = ImageTk.PhotoImage(pippiImage)

elDeafoImage = Image.open("elDeafo.jpg").resize((250, 350))
elDeafoPhoto = ImageTk.PhotoImage(elDeafoImage)

#GRID THE WIDGETS
###########

root.minsize(width=450, height=200)
mainframe.grid(row=1, column=1, padx=50, pady=50)
titleLabel.grid(row=1, column=1)
lbl_with_my_gif.grid(row=1, column=2)
levelLabel.grid(row=2, column=1, sticky=W)
levelSpinbox.grid(row=2, column=2, sticky=E)
bookTypeLabel.grid(row=3, column=1, sticky=W)
bookTypesOption.grid(row=3, column=2, sticky=E)

passageFrame.grid(row=4, column=1, rowspan=3, columnspan=3, sticky=NW, pady=10)
passageLabel.grid(row=1, sticky=W)

bookTitleFrame.grid(row=7, column=1, sticky=W)
title1Radio.grid(row=1, sticky=W)
title2Radio.grid(row=2, sticky=W)
title3Radio.grid(row=3, sticky=W)
title4Radio.grid(row=4, sticky=W)

authorFrame.grid(row=7, column=2, sticky=W, ipadx=35)
author1Radio.grid(row=1, sticky=W)
author2Radio.grid(row=2, sticky=W)
author3Radio.grid(row=3, sticky=W)
author4Radio.grid(row=4, sticky=W)

submitAnswerButton.grid(row=8, column=1, pady=10, sticky=W)
nextQButton.grid(row=8, column=2, pady=10)
themeScale.grid(row=9, column=1, sticky=W)
ratingButton.grid(row=9, column=2)
correctLabel.grid(row=10, column=1, sticky=NW)
correctCounterLabel.grid(row=11, column=1, sticky=NW)
incorrectLabel.grid(row=10, column=2, sticky=NW)
incorrectCounterLabel.grid(row=11, column=2, sticky=NW)

secframe.grid(row=1, column=10, rowspan=16, columnspan=16, pady=10)
cv.grid(row=3, column=1, columnspan=15, rowspan=15, padx=50, pady=50)

root.mainloop()
